export interface Employee {
    employeeId: string;
    name: string;
    email: string;
    phone: string;
    jobTitle: string;
    departmentId: string;
    dateOfJoining: string;
    status: string;
  }