export interface Holiday {
    title: string;
    date: string;
    description?: string;
    type?: string;
    _id?: string;
    _class?: string;
  }
  