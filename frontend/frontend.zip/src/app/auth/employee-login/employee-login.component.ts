import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-login',
  imports: [],
  templateUrl: './employee-login.component.html',
  styleUrl: './employee-login.component.css'
})
export class EmployeeLoginComponent {

}
